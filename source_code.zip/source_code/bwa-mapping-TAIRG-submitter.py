#! /usr/bin/env python
# -*- coding: utf-8 -*-
# pylint: disable=C0103, W1514, C0301, C0413

"""

submit BWA mapping jobs to slurm for each SE reads

"""

import os
import jitu


template = """#!/bin/bash -e
#SBATCH  --job-name=jobBASE
#SBATCH  -o     BASE.out
#SBATCH  -e     BASE.err
#SBATCH  --mem  40G
#SBATCH  -c     8
#SBATCH  -t     20:29:00 
#SBATCH  -p     jic-medium

#aln -t using 8 threads
# -l 32        seed length
# -k 2         mismatches allowed in seed
# -q 5


mkdir -p BAM

singularity exec ~/BUILD/VERN/idr_bwa.sif bwa aln -q 5 -l 32 -k 2 -t 8 ../ref/TAIR10Genome.fasta  FASTQ  > BASE.sai
 
sleep 2s

#for bwa samse: we are building sam
singularity exec ~/BUILD/VERN/idr_bwa.sif bwa samse ../ref/TAIR10Genome.fasta  BASE.sai FASTQ  > BASE.sam


singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools view -bt ../ref/TAIR10Genome.fasta  -o BASE_unsorted.bam  BASE.sam

singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools sort -@ 8  -o  BAM/BASE.bam  BASE_unsorted.bam
 
singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools index    BAM/BASE.bam 

singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools flagstat BAM/BASE.bam  >  BASE.stat

rm BASE_unsorted.bam
rm BASE.sam

echo DONE

"""


if __name__ == '__main__':

    # load all the samples info to reads name from the tsv

    samples2fastq_concatted = {'VEL1-FLAG-NV-rep1': 'VEL1-FLAG-NV-rep1.fq.gz', 'VEL1-FLAG-NV-rep3': 'VEL1-FLAG-NV-rep3.fq.gz', 'VEL1-FLAG-NV-rep2': 'VEL1-FLAG-NV-rep2.fq.gz', 'ColFRI-6WT0-Input-for-ColFRI-FLAG-Rep1': 'ColFRI-6WT0-Input-for-ColFRI-FLAG-Rep1.fq.gz', 'ColFRI-NV-IP-For-GFP-ColFR-Rep2': 'ColFRI-NV-IP-For-GFP-ColFR-Rep2.fq.gz', 'VRN5-YFP-NV-rep3': 'VRN5-YFP-NV-rep3.fq.gz', 'VEL1-FLAG-6WT0-rep1': 'VEL1-FLAG-6WT0-rep1.fq.gz', 'VEL1-FLAG-6WT0-rep2': 'VEL1-FLAG-6WT0-rep2.fq.gz', 'VEL1-FLAG-6WT0-rep3': 'VEL1-FLAG-6WT0-rep3.fq.gz', 'VEL1-FLAG-NV-input-rep2': 'VEL1-FLAG-NV-input-rep2.fq.gz', 'VEL1-FLAG-NV-input-rep3': 'VEL1-FLAG-NV-input-rep3.fq.gz', 'VEL1-FLAG-NV-input-rep1': 'VEL1-FLAG-NV-input-rep1.fq.gz', 'VIN3-eGFP-6WT0-rep1': 'VIN3-eGFP-6WT0-rep1.fq.gz', 'VIN3-eGFP-6WT0-rep2': 'VIN3-eGFP-6WT0-rep2.fq.gz', 'VIN3-eGFP-6WT0-rep3': 'VIN3-eGFP-6WT0-rep3.fq.gz', 'VIN3-eGFP-NV-rep1': 'VIN3-eGFP-NV-rep1.fq.gz', 'VRN5-YFP-6WT0-rep2': 'VRN5-YFP-6WT0-rep2.fq.gz', 'VRN5-YFP-6WT0-rep1': 'VRN5-YFP-6WT0-rep1.fq.gz', 'VIN3-eGFP-NV-rep2': 'VIN3-eGFP-NV-rep2.fq.gz', 'ColFRI-NV-IP-for-ColFRI-FLAG-Rep1': 'ColFRI-NV-IP-for-ColFRI-FLAG-Rep1.fq.gz', 'ColFRI-NV-IP-for-ColFRI-FLAG-Rep2': 'ColFRI-NV-IP-for-ColFRI-FLAG-Rep2.fq.gz', 'VIN3-eGFP-NV-input-rep2': 'VIN3-eGFP-NV-input-rep2.fq.gz', 'ColFRI-6WT0-For-GFP-ColFR-Rep1': 'ColFRI-6WT0-For-GFP-ColFR-Rep1.fq.gz', 'ColFRI-6WT0-For-GFP-ColFR-Rep2': 'ColFRI-6WT0-For-GFP-ColFR-Rep2.fq.gz', 'ColFRI-6WT0-Input-For-GFP-ColFR-Rep1': 'ColFRI-6WT0-Input-For-GFP-ColFR-Rep1.fq.gz', 'VRN5-YFP-6WT0-input-rep1': 'VRN5-YFP-6WT0-input-rep1.fq.gz', 'VRN5-YFP-6WT0-input-rep2': 'VRN5-YFP-6WT0-input-rep2.fq.gz', 'VRN5-YFP-6WT0-input-rep3': 'VRN5-YFP-6WT0-input-rep3.fq.gz', 'ColFRI-NV-input-for-ColFRI-FLAG-Rep2': 'ColFRI-NV-input-for-ColFRI-FLAG-Rep2.fq.gz', 'ColFRI-NV-input-for-ColFRI-FLAG-Rep1': 'ColFRI-NV-input-for-ColFRI-FLAG-Rep1.fq.gz', 'VRN5-YFP-NV-rep2': 'VRN5-YFP-NV-rep2.fq.gz', 'VEL1-FLAG-6WT0-input-rep3': 'VEL1-FLAG-6WT0-input-rep3.fq.gz', 'VEL1-FLAG-6WT0-input-rep2': 'VEL1-FLAG-6WT0-input-rep2.fq.gz', 'VEL1-FLAG-6WT0-input-rep1': 'VEL1-FLAG-6WT0-input-rep1.fq.gz', 'VIN3-eGFP-NV-input-rep1': 'VIN3-eGFP-NV-input-rep1.fq.gz', 'VIN3-eGFP-6WT0-input-rep3': 'VIN3-eGFP-6WT0-input-rep3.fq.gz', 'VIN3-eGFP-6WT0-input-rep2': 'VIN3-eGFP-6WT0-input-rep2.fq.gz', 'VIN3-eGFP-6WT0-input-rep1': 'VIN3-eGFP-6WT0-input-rep1.fq.gz', 'VRN5-YFP-NV-rep1': 'VRN5-YFP-NV-rep1.fq.gz', 'ColFRI-NV-input-For-GFP-ColFR-Rep2': 'ColFRI-NV-input-For-GFP-ColFR-Rep2.fq.gz', 'ColFRI-NV-input-For-GFP-ColFR-Rep1': 'ColFRI-NV-input-For-GFP-ColFR-Rep1.fq.gz', 'VRN5-YFP-6WT0-rep3': 'VRN5-YFP-6WT0-rep3.fq.gz', 'ColFRI-NV-IP-For-GFP-ColFR-Rep1': 'ColFRI-NV-IP-For-GFP-ColFR-Rep1.fq.gz', 'VRN5-YFP-NV-input-rep1': 'VRN5-YFP-NV-input-rep1.fq.gz', 'ColFRI-6WT0-Input-For-GFP-ColFR-Rep2': 'ColFRI-6WT0-Input-For-GFP-ColFR-Rep2.fq.gz', 'VRN5-YFP-NV-input-rep3': 'VRN5-YFP-NV-input-rep3.fq.gz', 'VRN5-YFP-NV-input-rep2': 'VRN5-YFP-NV-input-rep2.fq.gz', 'ColFRI-6WT0-for-ColFRI-FLAG-Rep1': 'ColFRI-6WT0-for-ColFRI-FLAG-Rep1.fq.gz' , 'CLF-GFP-Rep2': 'CLF-GFP-Rep2.fq.gz', 'CLF-GFP-Rep1': 'CLF-GFP-Rep1.fq.gz', '35S_GFP_input_control': '35S_GFP_input_control.fq.gz', 'SWN-GFP-Rep2': 'SWN-GFP-Rep2.fq.gz', 'SWN-GFP-Rep1': 'SWN-GFP-Rep1.fq.gz'}
   

    # construct a job array
    with open('all-batch.sh', 'w') as bout:

        for t, sample in enumerate(samples2fastq_concatted.keys(), 1):

            fastq_file = '../sra/' + samples2fastq_concatted[sample]

            assert os.path.exists(fastq_file)

            st = jitu.strMUT(template, {
                'SER': str(t),
                'BASE': sample,
                'FASTQ': fastq_file, })

            with open('job' + str(t) + '.sh', 'w') as outf:
                outf.write(st)
            bout.write('sbatch ' + 'job' + str(t) + '.sh' + '\n')

print('DONE')
