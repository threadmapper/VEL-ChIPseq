import math

samples = ['40V_H3K27_me3_rep2_peaks', 'H3K27me3_NV_1_peaks', 'H3K27me3_NV_2_peaks', 'VAL1-GFP-val1-Rep1_peaks', 'VAL1-GFP-val1-Rep2_peaks']


#q = 0.0000000001 # Q10
#q = 0.000000000000001 # Q_15
q = 1e-15

threshold = -math.log(q, 10)
print ('threshold = ', threshold) 
folder = 'Q'+ str(int(round(threshold)))
print ('folder = ', folder)

 
for s in samples:
    with open(s + '.broadPeak') as inp, open(folder + '/' + s[:-6] + '.bed', 'w') as outf:
        for line in inp:
            A = line.strip().split()   
            qscore =  float(A[-1])
            #assert qscore > threshold , A
            if qscore > threshold:
               outf.write(line.strip() + '\n')
   

""""
1.00E-15
threshold =  15.0
folder =  Q_15
"""


            