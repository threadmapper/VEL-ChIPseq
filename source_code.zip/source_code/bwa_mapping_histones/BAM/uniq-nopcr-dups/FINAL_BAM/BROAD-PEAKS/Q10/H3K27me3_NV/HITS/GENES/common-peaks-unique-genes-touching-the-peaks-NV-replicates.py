"""

Find the unique genes overlapping the 
common peak area 

p1 -------xxxxxxxxx--------
p2 ---------xxxxxxxxxx--------


p1 ---------xxxxxxx--------
p2 ---------xxxxxxx--------
            xxxxxxx   
             gggggggggg

so common list from each rep gives the identical gene list

"""

from collections import defaultdict


if __name__ == '__main__':

    trt_files = ['H3K27me3_NV_1.bed', 'H3K27me3_NV_2.bed']

    for trt in sorted(trt_files):
        print(trt)
        outUnique_csv = trt[:-4] + '-peak-touching-genes-unique_genelist.csv'
        head_broad = ['chrom', 'p_beg', 'p_end', 'peak_name', 'score', 'dot', 'p', 'fold', 'q', 'sample', 'gene_chrom', 'TAIR10',
                      'gene', 'g_beg', 'g_end', 'dot', 'strand', 'dot', 'namer', 'TAG']

        uniq_genes_touching_peaks = set()
        with open(trt) as inp:
            for line in inp:
                A = line.strip().split('\t')
                if A:
                    assert len(A) == len(head_broad)
                    
                    D = dict(zip(head_broad, A))
                    peak = D['peak_name']

                    # gene id
                    namer = D['namer']  # 19 ID=AT1G01010;Note=protein_coding_gene;Name=AT1G01010
                    assert 'Name=' in namer
                    gene_name = namer.split(';')[-1].split('=')[1]
                    gene_id = namer.split(';')[0].split('=')[1]
                    assert gene_id.startswith('AT')
                    uniq_genes_touching_peaks.add(gene_id)  # all the genes in the intersection file

        with open(outUnique_csv, 'w') as outf:
            for g in uniq_genes_touching_peaks:
                outf.write(g + '\n')
                # -----------
        print('uniq_genes_found_touching_peaks = ', len(uniq_genes_touching_peaks))
