"""
source  python-3.7.2

"""

import subprocess
import os


categ = 'NV'
trt_files = ['H3K27me3_NV_1.bed', 'H3K27me3_NV_2.bed']

for g in trt_files:
  assert os.path.isfile(g) 

names = [trt[:-4] for trt in  trt_files]
with open(categ + '-multi.txt','w') as outf:    
    #cmd = ['/nbi/software/testing/bedtools/2.27.1/x86_64/bin/bedtools',  'multiinter', '-header', '-names'] + names + ['-i'] +  trt_files
    cmd = ['bedtools',  'multiinter', '-header', '-names'] + names + ['-i'] +  trt_files
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, text=True)
    for line in p.stdout:
        pipe_out = line.strip() #+ '\t@' + 'VEL1-control' ##g[:-4]) #
        outf.write(pipe_out + '\n') 

print ('trt_files = ', trt_files)
print ('DONE')
