"""
# 5kb annoted as genes
/nbi/software/testing/bedtools/2.27.1/x86_64/bin/bedtools window -a T1.bed -b TAIR10_GFF3_unique_genes.gff  -w 5000
# 5kb protein coding
/nbi/software/testing/bedtools/2.27.1/x86_64/bin/bedtools window -a T1.bed -b TAIR10_GFF3_protein_coding_genes.gff  -w 5000

# 5kb annoted as genes
/nbi/software/testing/bedtools/2.27.1/x86_64/bin/bedtools window -a h_s_VEL1@Before_cold@12_8_VEL1_NV.bed -b TAIR10_GFF3_unique_genes.gff  -w 5000

"""
import subprocess
import os
import time 



##----before--------
#categ = 'before'
#trt_files = [ 'h_s_' + t for t in ['VEL1@Before_cold@12_8_VEL1_NV.bed', 'VEL1@Before_cold@23_9_VEL1_NV.bed', 'VEL1@Before_cold@31_8_VEL1_NV.bed']] #, 'VEL1@Cold@16_9_VEL16W0.bed', 'VEL1@Cold@26_7_VEL1_6W0.bed', 'VEL1@Cold@7_9_VEL1_6W0.bed'] ]

##----cold--------
categ = '40V'

files = ['40V_H3K27_me3_rep2.bed',  ]

trt_files = [  t for t in files ]

for g in trt_files:
  print(g)
  assert os.path.isfile(g) 
  #sumit_file = gen_submit_file(peak_file = g, sumit_file = "submit-" + g[4:]) 
  #time.sleep(3)

  with open('GENES/' + g ,'w') as outf:    
    cmd = ['bedtools',  'window', '-a', g , '-b',  'TAIR10_GFF3_unique_genes.gff' , '-w', '0']
    print( cmd)
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, text=True)
    for line in p.stdout:
        pipe_out = line.strip() + '\t@' + g[:-4] #
        outf.write(pipe_out + '\n') 

print ('DONE')