import subprocess
import os
import time

categ = 'VAL1'

output_multi_bed = categ + '-multi.bed'
# write multibed
with open(categ +'-multi.txt') as inp, open(output_multi_bed, 'w') as outf:
  for i, line in enumerate(inp,1):
      A = line.strip().split('\t')    
      if i == 1:
         header = A[:]
         candi_beds = [ a + '.bed' for a in header[5:] ]
         continue

      d = dict(zip(header, A))   
      num = int(d['num'])
      if num >= 2: # in at least 2 samples: two or more
         pipe = [ d['chrom'], d['start'], d['end'] ]
         outf.write('\t'.join(pipe) + '\n')    

#
time.sleep(3)

for g in candi_beds:
  print(g)
  assert os.path.isfile(g) 
  with open('HITS/h_' + g ,'w') as outf:    
    cmd = ['bedtools',  'intersect', '-a', g , '-b',  output_multi_bed  ]
    print( cmd)
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, text=True)
    for line in p.stdout:
        pipe_out = line.strip() + '\t@' + g[:-4] #
        outf.write(pipe_out + '\n') 
