import jitu
import os
from collections import defaultdict


""" pairs

# we need CLF and SWN 
GSM2916533      CLF-GFP Rep1            @  SRX3544214
GSM2916534      CLF-GFP Rep2               SRX3544215 
GSM2916535      SWN-GFP Rep1               SRX3544216 
GSM2916536      SWN-GFP Rep2               SRX3544217
GSM2916537      35S_GFP (input) [control]  SRX3544218


# VAL1  paired ends reads :
GSM4317615      VAL1-GFP-val1-1                         SRX7734762 
GSM4317616      VAL1-GFP-val1-2                         SRX7734763
GSM4317617      VAL1-GFP-val1-input [control]           SRX7734764

# missing NV1 and NV2
GSM3735476_H3K27me3_NV_1_peaks.txt                      SRX5735621
GSM3735485_H3K27me3_NV_2_peaks.txt                      SRX5735630               # NV_H3K27me3_rep2
GSM3735473            NV_input                          SRX5735618

#
GSM3735486 40V_H3K27_me3_rep2  
GSM3735474 40V_input (use as input for peak calling for 40V)

"""

#categ = ['35S_GFP_input_control', '40V_H3K27_me3_rep2', '40V_input_control', 'CLF-GFP-Rep1', 'CLF-GFP-Rep2', 'H3K27me3_NV_1', 'H3K27me3_NV_2', 'NV_input_control', 'SWN-GFP-Rep1', 'SWN-GFP-Rep2', 'VAL1-GFP-val1-Rep1', 'VAL1-GFP-val1-Rep2', 'VAL1-GFP-val1-input-control']
#print len(categ) # 13 bams

baseD = {


  'H3K27me3_NV_1' : {'TRT_BAM_FILE': 'H3K27me3_NV_1', 'CNTRL_BAM_FILE': 'NV_input_control'},
  'H3K27me3_NV_2' : {'TRT_BAM_FILE': 'H3K27me3_NV_2', 'CNTRL_BAM_FILE': 'NV_input_control'},
  '40V_H3K27_me3_rep2' : {'TRT_BAM_FILE': '40V_H3K27_me3_rep2', 'CNTRL_BAM_FILE': '40V_input_control'},

  'VAL1-GFP-val1-Rep1' : {'TRT_BAM_FILE': 'VAL1-GFP-val1-Rep1', 'CNTRL_BAM_FILE': 'VAL1-GFP-val1-input-control'},
  'VAL1-GFP-val1-Rep2' : {'TRT_BAM_FILE': 'VAL1-GFP-val1-Rep2', 'CNTRL_BAM_FILE': 'VAL1-GFP-val1-input-control'},

}


isolates = sorted(baseD.keys())
print len(isolates) # 9 

template="""#!/bin/bash -e
#SBATCH  --job-name=jobSER
#SBATCH  -o     jobSER.out
#SBATCH  -e     jobSER.err
#SBATCH  --mem  60gb
#SBATCH  -c     8
###SBATCH  -t   20:29:00 # time (D-HH:MM)
#SBATCH  -p     jic-short

mkdir -p BASE

# histone broad
singularity exec /hpc-home/cheemaj/BUILD/MACS3/macs3_a7.simg macs3  callpeak -t TRT_BAM_FILE  -c  CNTRL_BAM_FILE  -f BAMPE  -g 113582948  --bdg --outdir BASE  -n BASE  --nomodel  --broad-cutoff 0.05 --broad 

echo DONE

"""

#
t=1
with open('ALL-BATCH.sh','w') as kodaf:
 for isolate in isolates:

  print t, isolate

  CNTRL_BAM_FILE =  baseD[isolate]['CNTRL_BAM_FILE'] + '.bam'
  TRT_BAM_FILE =    baseD[isolate]['TRT_BAM_FILE'] + '.bam'
  print CNTRL_BAM_FILE, TRT_BAM_FILE
 

  assert os.path.exists( CNTRL_BAM_FILE ), CNTRL_BAM_FILE 
  assert os.path.exists( TRT_BAM_FILE ),  TRT_BAM_FILE

  st = jitu.strMUT(template, {
    'SER': str(t), 
    'BASE': isolate,
    'tag' : 'tag' + str(t), 
    'CNTRL_BAM_FILE': CNTRL_BAM_FILE,
    'TRT_BAM_FILE':   TRT_BAM_FILE,
  }) 

  #print st 
  with open('job'+ str(t)+'.sh', 'w') as outf:
       outf.write(st)
  kodaf.write('sbatch ' + 'job'+ str(t)+'.sh' +'\n')
  t += 1

print ('DONE')