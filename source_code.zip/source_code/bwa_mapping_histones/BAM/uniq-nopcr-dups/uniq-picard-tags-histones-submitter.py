#! /usr/bin/env python
# -*- coding: utf-8 -*-
# pylint: disable=C0103, W1514, C0301, C0413

"""


"""

import os
import jitu


template = """#!/bin/bash -e
#SBATCH  --job-name=jobBASE
#SBATCH  -o     BASE.out
#SBATCH  -e     BASE.err
#SBATCH  --mem  40G
#SBATCH  -c     8
#SBATCH  -t     20:29:00 
#SBATCH  -p     jic-a100


mkdir -p FINAL_BAM 


singularity exec ~/BUILD/VERN/idr_bwa.sif sambamba view -t 8 -h -f bam -F "mapping_quality >= 1 and not (unmapped or secondary_alignment) and not ([XA] != null or [SA] != null)" ../BASE.bam -o BASE_uniq.bam
singularity exec ~/BUILD/VERN/idr_bwa.sif samtools index BASE_uniq.bam 
singularity exec ~/BUILD/VERN/idr_bwa.sif samtools flagstat BASE_uniq.bam  > BASE_uniq.stat


# remove reads without MAPQ>=30
singularity exec ~/BUILD/VERN/idr_bwa.sif samtools view -@ 8  -F 772  -b BASE_uniq.bam  Chr1 Chr2 Chr3 Chr4 Chr5 -o FILTER/BASE.filter_unsorted.bam
singularity exec ~/BUILD/VERN/idr_bwa.sif samtools sort -@ 8  -o FILTER/BASE.filter.bam  FILTER/BASE.filter_unsorted.bam

# Index filtered reads
singularity exec ~/BUILD/VERN/idr_bwa.sif samtools  index    FILTER/BASE.filter.bam
singularity exec ~/BUILD/VERN/idr_bwa.sif samtools  flagstat FILTER/BASE.filter.bam  > FILTER/BASE.filter.bam.stat



sleep 5s

# mark duplicates with picard
singularity exec ~/BUILD/VERN/idr_bwa.sif picard MarkDuplicates I=FILTER/BASE.filter.bam O=FILTER/BASE.dupmark_unsorted.bam  M=FILTER/BASE.dup.qc  VALIDATION_STRINGENCY=LENIENT  REMOVE_DUPLICATES=false ASSUME_SORTED=true

sleep 5s

# sort reads after marking the duplicates
singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools sort -@ 8 -o FILTER/BASE.dupmark.bam  FILTER/BASE.dupmark_unsorted.bam

# index the sorted reads
singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools index    FILTER/BASE.dupmark.bam
singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools flagstat FILTER/BASE.dupmark.bam > FILTER/BASE.dupmark.bam.stat


# remove duplicates
singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools view -@ 8  -F 1796  -b FILTER/BASE.dupmark.bam -o  FILTER/BASE.dupmark.nodup_unsorted.bam

singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools sort -@ 8  -o FINAL_BAM/BASE.bam  FILTER/BASE.dupmark.nodup_unsorted.bam

# index unique reads
singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools  index     FINAL_BAM/BASE.bam
singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools  flagstat  FINAL_BAM/BASE.bam >  FINAL_BAM/BASE.bam.stat




echo DONE

"""


if __name__ == '__main__':


    samples = ['NV_input_control', 'H3K27me3_NV_1', 'VAL1-GFP-val1-Rep2', 'VAL1-GFP-val1-Rep1', 'H3K27me3_NV_2', '40V_H3K27_me3_rep2', 'VAL1-GFP-val1-input-control', '40V_input_control']
   

    # construct a job array
    with open('all-batch.sh', 'w') as bout:

        for t, sample in enumerate(samples, 1):

            
            st = jitu.strMUT(template, {
                'SER': str(t),
                'BASE': sample,
                  })

            with open('job' + str(t) + '.sh', 'w') as outf:
                outf.write(st)
            bout.write('sbatch ' + 'job' + str(t) + '.sh' + '\n')

print('DONE')
