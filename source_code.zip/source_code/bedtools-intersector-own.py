#! /usr/bin/env python
# -*- coding: utf-8 -*-
# pylint: disable=C0103, W1514, C0301, C0413

"""
- Find the percentage bp overlaps over the genome length
bedtools intersect -wa  -a onepeak.bed  -b twopeak.bed >  one_peaks_overlappingtwo.bed

bedtools intersect -wa -u  -a vel1.bed  -b vin3.bed    >  ne_peaks_overlappingtwo.bed


singularity exec py3bed.sif python3 bedtools-intersector.py


"""

from collections import defaultdict
import glob
import itertools
import subprocess
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


def load_number_of_peaks(bed_file='x.bed'):
    """
     Load bed file return number of lines
    :param bed_file:
    :return: n
    """
    with open(bed_file) as inp:
        n = 0
        for line in inp:
            A = line.strip().split()
            if A:
                n += 1
    return n


if __name__ == '__main__' and __package__ is None:

    # ---------------------------------------
    bed_order = sorted(glob.glob('*.bed'))
    sample_order = [bed[:-4] for bed in bed_order]
    print('samples = ', sample_order)

    num_peaks = {bed[:-4]: load_number_of_peaks(bed_file=bed) for bed in bed_order}
    print('num_peaks= ', num_peaks)

    pairs = list(itertools.combinations(sample_order, 2))

    hits = defaultdict(int)
    for a in sample_order:
        for b in sample_order:
            cmd = ['bedtools',  'intersect', '-wa',  '-u', '-a',  a + '.bed', '-b', b + '.bed']
            with subprocess.Popen(cmd, stdout=subprocess.PIPE, text=True) as p:
                for out_line in p.stdout:
                    if out_line:
                        hits[(a, b)] += 1

    overlap_matrix = {}
    with open('own-number-peaks-a-to-b-overlap.tab', 'w') as outf:
        header = ['sample1', 'sample2',  'sample1_peaks', 'sample2_peaks',
                  'overlap_peaks', 'percentage_overlap']
        print(header)
        outf.write('\t'.join(map(str, header)) + '\n')
        for a in sample_order:
            for b in sample_order:
                overlap_matrix[(a, b)] = 100.0*(hits[(a, b)] / hits[(a, a)])

                assert num_peaks[a] == hits[(a, a)]
                assert num_peaks[b] == hits[(b, b)]

                pipe = [a, b, num_peaks[a], num_peaks[b], hits[(a, b)], f'{overlap_matrix[(a, b)]:.2f}']
                outf.write('\t'.join(map(str, pipe)) + '\n')
                print(pipe)

    box = []
    with open('own-a-to-b-overlap-melt.csv', 'w') as outf:
        outf.write(','.join(map(str, ['x', 'y', 'overlap'])) + '\n')
        for a in sample_order:
            box.append([overlap_matrix[(a, b)] for b in sample_order])
            for b in sample_order:
                outf.write(','.join(map(str, [a, b, overlap_matrix[(a, b)]])) + '\n')

    data = pd.DataFrame(box, columns=sample_order, index=sample_order)
    print(data)
    fig = plt.figure()
    ax = fig.add_subplot(111)
    cax = ax.matshow(data, cmap='coolwarm', vmin=0, vmax=100)
    fig.colorbar(cax)
    ticks_ = np.arange(0, len(data.columns), 1)
    ax.set_xticks(ticks_)
    plt.xticks(rotation=90)
    ax.set_yticks(ticks_)
    ax.set_xticklabels(data.columns)
    ax.set_yticklabels(data.columns)

    plt.tight_layout()
    plt.savefig('own-percentage_peak_overlap.pdf')

    print('DONE')
