#! /usr/bin/env python
# -*- coding: utf-8 -*-
# pylint: disable=C0103, W1514, C0301, C0413

"""

submit fastq pooling merger

"""

import jitu
import sys
import os
from collections import defaultdict

template = """#!/bin/bash -e
#SBATCH  --job-name=jobSER
#SBATCH  -o     BASE.out
#SBATCH  -e     BASE.err
#SBATCH  --mem  20gb
#SBATCH  -c     8
#SBATCH  -p     jic-a100


mkdir -p MERGED

singularity exec ~/BUILD/VERN/idr_bwa.sif  bamtools merge -list BASE.txt  -out MERGED/BASE.bam

singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools index  MERGED/BASE.bam

echo DONE

"""

if __name__ == '__main__':

    # construct a job array
    with open('all-batch.sh', 'w') as bout:
        with open('replicates-merge-plan.tab') as inp:
            for t, line in enumerate(inp, 1):
                A = line.strip().split('\t')
                base_name = A[0]     
                with open(base_name + '.txt', 'w') as outf:
                     for rep in A[1:]:
                         bamfiler = '../' + rep + '.bam' 
                         assert os.path.exists(bamfiler)    
                         outf.write(bamfiler + '\n')
            
                st = jitu.strMUT(template, dict(SER=str(t),
                                                BASE=base_name,)
                                 )

                with open('job' + str(t) + '.sh', 'w') as outf:
                    outf.write(st)
                bout.write('sbatch ' + 'job' + str(t) + '.sh' + '\n')

print('DONE')
