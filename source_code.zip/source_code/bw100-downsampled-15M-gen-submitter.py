import jitu
import glob


 
 
template="""#!/bin/bash -e
#SBATCH  --job-name=jobSER
#SBATCH  -o     tobSER.out
#SBATCH  -e     tobSER.err
#SBATCH  --mem  25gb
#SBATCH  -c     8
#SBATCH  -p     jic-short

mkdir -p BW100
singularity exec ~/BUILD/DEEPTOOLS/deeptools.sif  bamCoverage --bam BASE-sampled.bam  -o BW100/BASE.bw  --binSize 100   --normalizeUsing RPGC    --effectiveGenomeSize 113582948  --filterRNAstrand forward  --numberOfProcessors 8

echo DONE

"""

isolates = ['ColFRI-6WT0-For-GFP-ColFR', 'ColFRI-6WT0-Input-For-GFP-ColFR', 'ColFRI-NV-IP-For-GFP-ColFR', 'ColFRI-NV-IP-for-ColFRI-FLAG', 'ColFRI-NV-input-for-ColFRI-FLAG', 'VEL1-FLAG-6WT0', 'VEL1-FLAG-6WT0-input', 'VEL1-FLAG-NV', 'VEL1-FLAG-NV-input', 'VIN3-eGFP-6WT0', 'VIN3-eGFP-6WT0-input', 'VIN3-eGFP-NV', 'VIN3-eGFP-NV-input', 'VRN5-YFP-6WT0', 'VRN5-YFP-6WT0-input', 'VRN5-YFP-NV', 'VRN5-YFP-NV-input', 'SWN-GFP', 'CLF-GFP']

t=1
with open('all-batch.sh','w') as kodaf:
 for isolate in isolates:
  print t, isolate


  st = jitu.strMUT(template, {
    'SER': str(t), 
    'BASE': isolate,
  }) 
  #print st 
  with open('hob'+ str(t)+'.sh', 'w') as outf:
       outf.write(st)
  kodaf.write('sbatch ' + 'hob'+ str(t)+'.sh' +'\n')
  t += 1

print ('DONE')