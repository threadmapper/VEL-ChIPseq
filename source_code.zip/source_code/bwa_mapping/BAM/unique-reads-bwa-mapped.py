"""
# https://bioinformatics.stackexchange.com/questions/508/obtaining-uniquely-mapped-reads-from-bwa-mem-alignment
# samtools can now do filtering based on an expression that includes tag variables. 
#  the expression we are using exclude any reads that have either an XA or SA tag:

  samtools view -b mapped.bam -e '!([XA] | [SA])' > unique_mapped.bam

"""

import jitu
import glob


# isolates = sorted([g[:-4] for g in glob.glob('*.bam')])

# 53
isolates =  ['35S_GFP_input_control', 'CLF-GFP-Rep1', 'CLF-GFP-Rep2', 'ColFRI-6WT0-For-GFP-ColFR-Rep1', 'ColFRI-6WT0-For-GFP-ColFR-Rep2', 'ColFRI-6WT0-Input-For-GFP-ColFR-Rep1', 'ColFRI-6WT0-Input-For-GFP-ColFR-Rep2', 'ColFRI-6WT0-Input-for-ColFRI-FLAG-Rep1', 'ColFRI-6WT0-for-ColFRI-FLAG-Rep1', 'ColFRI-NV-IP-For-GFP-ColFR-Rep1', 'ColFRI-NV-IP-For-GFP-ColFR-Rep2', 'ColFRI-NV-IP-for-ColFRI-FLAG-Rep1', 'ColFRI-NV-IP-for-ColFRI-FLAG-Rep2', 'ColFRI-NV-input-For-GFP-ColFR-Rep1', 'ColFRI-NV-input-For-GFP-ColFR-Rep2', 'ColFRI-NV-input-for-ColFRI-FLAG-Rep1', 'ColFRI-NV-input-for-ColFRI-FLAG-Rep2', 'SWN-GFP-Rep1', 'SWN-GFP-Rep2', 'VEL1-FLAG-6WT0-input-rep1', 'VEL1-FLAG-6WT0-input-rep2', 'VEL1-FLAG-6WT0-input-rep3', 'VEL1-FLAG-6WT0-rep1', 'VEL1-FLAG-6WT0-rep2', 'VEL1-FLAG-6WT0-rep3', 'VEL1-FLAG-NV-input-rep1', 'VEL1-FLAG-NV-input-rep2', 'VEL1-FLAG-NV-input-rep3', 'VEL1-FLAG-NV-rep1', 'VEL1-FLAG-NV-rep2', 'VEL1-FLAG-NV-rep3', 'VIN3-eGFP-6WT0-input-rep1', 'VIN3-eGFP-6WT0-input-rep2', 'VIN3-eGFP-6WT0-input-rep3', 'VIN3-eGFP-6WT0-rep1', 'VIN3-eGFP-6WT0-rep2', 'VIN3-eGFP-6WT0-rep3', 'VIN3-eGFP-NV-input-rep1', 'VIN3-eGFP-NV-input-rep2', 'VIN3-eGFP-NV-rep1', 'VIN3-eGFP-NV-rep2', 'VRN5-YFP-6WT0-input-rep1', 'VRN5-YFP-6WT0-input-rep2', 'VRN5-YFP-6WT0-input-rep3', 'VRN5-YFP-6WT0-rep1', 'VRN5-YFP-6WT0-rep2', 'VRN5-YFP-6WT0-rep3', 'VRN5-YFP-NV-input-rep1', 'VRN5-YFP-NV-input-rep2', 'VRN5-YFP-NV-input-rep3', 'VRN5-YFP-NV-rep1', 'VRN5-YFP-NV-rep2', 'VRN5-YFP-NV-rep3']



template="""#!/bin/bash -e
#SBATCH  --job-name=jobSER
#SBATCH  -o     tobSER.out
#SBATCH  -e     tobSER.err
#SBATCH  --mem  25gb
#SBATCH  -c     18
#SBATCH  -p     jic-a100


singularity exec ~/BUILD/VERN/idr_bwa.sif sambamba view -t 8 -h -f bam -F "mapping_quality >= 1 and not (unmapped or secondary_alignment) and not ([XA] != null or [SA] != null)" ../BASE.bam -o BASE_uniq.bam
singularity exec ~/BUILD/VERN/idr_bwa.sif samtools index BASE_uniq.bam 
singularity exec ~/BUILD/VERN/idr_bwa.sif samtools flagstat BASE_uniq.bam  > BASE_uniq.stat



echo DONE

"""

t=1
with open('all-batch.sh','w') as kodaf:
 for isolate in isolates:
  print (t, isolate)


  st = jitu.strMUT(template, {
    'SER': str(t), 
    'BASE': isolate,
  }) 
  #print st 
  with open('hob'+ str(t)+'.sh', 'w') as outf:
       outf.write(st)
  kodaf.write('sbatch ' + 'hob'+ str(t)+'.sh' +'\n')
  t += 1

print ('DONE')