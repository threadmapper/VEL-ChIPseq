"""
Check the unique named reads

samtools view  35S_GFP_input_control.bam | cut -f 1  > read_names.txt


"""

from collections import Counter

red = Counter()
with open('read_names.txt') as inp:
    for line in inp:
        red[line.strip()] += 1

print(red.most_common(10))

 