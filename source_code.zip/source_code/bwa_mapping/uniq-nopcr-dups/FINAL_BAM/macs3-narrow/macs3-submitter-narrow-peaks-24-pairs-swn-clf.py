#! /usr/bin/env python
# -*- coding: utf-8 -*-
# pylint: disable=C0103, W1514, C0301, C0413

"""

submit macs3 peak calling jobs to slurm for each bam pairs

"""

import jitu
import os
from collections import defaultdict

template = """#!/bin/bash -e
#SBATCH  --job-name=jobSER
#SBATCH  -o     BASE.out
#SBATCH  -e     BASE.err
#SBATCH  --mem  60gb
#SBATCH  -c     8
###SBATCH  -t   20:29:00 # time (D-HH:MM)
#SBATCH  -p     jic-short

mkdir -p BASE

singularity exec /hpc-home/cheemaj/BUILD/MACS3/macs3_a7.simg macs3  callpeak -t TRT_BAM_FILE  -c  CNTRL_BAM_FILE  -f BAM -g 113582948  -q 0.05  --bdg --outdir BASE  -n BASE  --nomodel   

echo DONE

"""

if __name__ == '__main__':

    # load all the samples info to reads name from the tsv
    experimentD =  {'VEL1-FLAG-NV-rep1': {'CNTRL_BAM_FILE': 'VEL1-FLAG-NV-input-rep1', 'TRT_BAM_FILE': 'VEL1-FLAG-NV-rep1'}, 
                    'VEL1-FLAG-NV-rep3': {'CNTRL_BAM_FILE': 'VEL1-FLAG-NV-input-rep3', 'TRT_BAM_FILE': 'VEL1-FLAG-NV-rep3'}, 
                    'VEL1-FLAG-NV-rep2': {'CNTRL_BAM_FILE': 'VEL1-FLAG-NV-input-rep2', 'TRT_BAM_FILE': 'VEL1-FLAG-NV-rep2'}, 
                    'VEL1-FLAG-6WT0-rep1': {'CNTRL_BAM_FILE': 'VEL1-FLAG-6WT0-input-rep1', 'TRT_BAM_FILE': 'VEL1-FLAG-6WT0-rep1'}, 
                    'VEL1-FLAG-6WT0-rep2': {'CNTRL_BAM_FILE': 'VEL1-FLAG-6WT0-input-rep2', 'TRT_BAM_FILE': 'VEL1-FLAG-6WT0-rep2'}, 
                    'VEL1-FLAG-6WT0-rep3': {'CNTRL_BAM_FILE': 'VEL1-FLAG-6WT0-input-rep3', 'TRT_BAM_FILE': 'VEL1-FLAG-6WT0-rep3'}, 
                    'ColFRI-6WT0-for-ColFRI-FLAG-Rep1': {'CNTRL_BAM_FILE': 'ColFRI-6WT0-Input-for-ColFRI-FLAG-Rep1', 'TRT_BAM_FILE': 'ColFRI-6WT0-for-ColFRI-FLAG-Rep1'},
                    'VIN3-eGFP-6WT0-rep1': {'CNTRL_BAM_FILE': 'VIN3-eGFP-6WT0-input-rep1', 'TRT_BAM_FILE': 'VIN3-eGFP-6WT0-rep1'}, 
                    'VIN3-eGFP-6WT0-rep2': {'CNTRL_BAM_FILE': 'VIN3-eGFP-6WT0-input-rep2', 'TRT_BAM_FILE': 'VIN3-eGFP-6WT0-rep2'}, 
                    'VIN3-eGFP-6WT0-rep3': {'CNTRL_BAM_FILE': 'VIN3-eGFP-6WT0-input-rep3', 'TRT_BAM_FILE': 'VIN3-eGFP-6WT0-rep3'},
                    'VRN5-YFP-6WT0-rep3': {'CNTRL_BAM_FILE': 'VRN5-YFP-6WT0-input-rep3', 'TRT_BAM_FILE': 'VRN5-YFP-6WT0-rep3'}, 
                    'VRN5-YFP-6WT0-rep2': {'CNTRL_BAM_FILE': 'VRN5-YFP-6WT0-input-rep2', 'TRT_BAM_FILE': 'VRN5-YFP-6WT0-rep2'}, 
                    'VRN5-YFP-6WT0-rep1': {'CNTRL_BAM_FILE': 'VRN5-YFP-6WT0-input-rep1', 'TRT_BAM_FILE': 'VRN5-YFP-6WT0-rep1'}, 
                    'VIN3-eGFP-NV-rep2': {'CNTRL_BAM_FILE': 'VIN3-eGFP-NV-input-rep2', 'TRT_BAM_FILE': 'VIN3-eGFP-NV-rep2'}, 
                    'ColFRI-NV-IP-for-ColFRI-FLAG-Rep1': {'CNTRL_BAM_FILE': 'ColFRI-NV-input-for-ColFRI-FLAG-Rep1', 'TRT_BAM_FILE': 'ColFRI-NV-IP-for-ColFRI-FLAG-Rep1'}, 
                    'ColFRI-NV-IP-for-ColFRI-FLAG-Rep2': {'CNTRL_BAM_FILE': 'ColFRI-NV-input-for-ColFRI-FLAG-Rep2', 'TRT_BAM_FILE': 'ColFRI-NV-IP-for-ColFRI-FLAG-Rep2'}, 
                    'VIN3-eGFP-NV-rep1': {'CNTRL_BAM_FILE': 'VIN3-eGFP-NV-input-rep1', 'TRT_BAM_FILE': 'VIN3-eGFP-NV-rep1'}, 
                    'ColFRI-6WT0-For-GFP-ColFR-Rep1': {'CNTRL_BAM_FILE': 'ColFRI-6WT0-Input-For-GFP-ColFR-Rep1', 'TRT_BAM_FILE': 'ColFRI-6WT0-For-GFP-ColFR-Rep1'}, 
                    'ColFRI-6WT0-For-GFP-ColFR-Rep2': {'CNTRL_BAM_FILE': 'ColFRI-6WT0-Input-For-GFP-ColFR-Rep2', 'TRT_BAM_FILE': 'ColFRI-6WT0-For-GFP-ColFR-Rep2'}, 
                    'VRN5-YFP-NV-rep3': {'CNTRL_BAM_FILE': 'VRN5-YFP-NV-input-rep3', 'TRT_BAM_FILE': 'VRN5-YFP-NV-rep3'}, 
                    'VRN5-YFP-NV-rep2': {'CNTRL_BAM_FILE': 'VRN5-YFP-NV-input-rep2', 'TRT_BAM_FILE': 'VRN5-YFP-NV-rep2'}, 
                    'ColFRI-NV-IP-For-GFP-ColFR-Rep1': {'CNTRL_BAM_FILE': 'ColFRI-NV-input-For-GFP-ColFR-Rep1', 'TRT_BAM_FILE': 'ColFRI-NV-IP-For-GFP-ColFR-Rep1'},
                    'ColFRI-NV-IP-For-GFP-ColFR-Rep2': {'CNTRL_BAM_FILE': 'ColFRI-NV-input-For-GFP-ColFR-Rep2', 'TRT_BAM_FILE': 'ColFRI-NV-IP-For-GFP-ColFR-Rep2'}, 
                    'VRN5-YFP-NV-rep1': {'CNTRL_BAM_FILE': 'VRN5-YFP-NV-input-rep1', 'TRT_BAM_FILE': 'VRN5-YFP-NV-rep1'},


        'CLF-GFP-Rep1': {'CNTRL_BAM_FILE': '35S_GFP_input_control',
                                            'TRT_BAM_FILE': 'CLF-GFP-Rep1'},
        'CLF-GFP-Rep2': {'CNTRL_BAM_FILE': '35S_GFP_input_control',
                                            'TRT_BAM_FILE': 'CLF-GFP-Rep2'},

        'SWN-GFP-Rep1': {'CNTRL_BAM_FILE': '35S_GFP_input_control',
                                            'TRT_BAM_FILE': 'SWN-GFP-Rep1'},
        'SWN-GFP-Rep2': {'CNTRL_BAM_FILE': '35S_GFP_input_control',
                                            'TRT_BAM_FILE': 'SWN-GFP-Rep2'},

    }


    

    # construct a job array
    prefix = '../'
    with open('all-batch.sh', 'w') as bout:

        for t, sample in enumerate(sorted(experimentD.keys()), 1):
            print (sample)
            ctr_bam_file = prefix + experimentD[sample]['CNTRL_BAM_FILE'] + '.bam'
            trt_bam_file = prefix + experimentD[sample]['TRT_BAM_FILE'] + '.bam'

            assert os.path.exists(ctr_bam_file)
            assert os.path.exists(trt_bam_file)

            st = jitu.strMUT(template, dict(SER=str(t),
                                            BASE=sample,
                                            CNTRL_BAM_FILE=ctr_bam_file,
                                            TRT_BAM_FILE=trt_bam_file))

            with open('job' + str(t) + '.sh', 'w') as outf:
                outf.write(st)
            bout.write('sbatch ' + 'job' + str(t) + '.sh' + '\n')

print('DONE')
