import os
import shutil
from collections import defaultdict

if __name__ == '__main__':

    outprefix ='SURVIVAL-PEAKS'

    #logging.basicConfig(format='%(levelname)s-%(message)s')
    head = ['#protein', 'condition', 'treatment_biological_name', 'input_biological_name', 'treatment_sra_name', 'input_sra_name']

    experimentD = {}
    cluster_by_protein = defaultdict(list)
    with open('protein-conditions-treatment-input-reps.tab') as inp:
        next(inp)
        for line in inp:
            A  = line.strip().split('\t') 
            d = dict(zip(head,A))
            
            experimentD[d['treatment_sra_name']] = { 'TRT_BAM_FILE' : d['treatment_sra_name'],  'CNTRL_BAM_FILE':  d['input_sra_name']}
            #continue
 
   
            this_bed = d['treatment_sra_name'] + '_peaks.narrowPeak'
            assert os.path.exists(this_bed), d['treatment_biological_name'] + '  ' +  this_bed 
  
            out_bed_name = outprefix + '/' + '@'.join([d['#protein'], d['condition'], d['treatment_sra_name']])  + '.bed'
            two = '@'.join([d['#protein'], d['condition']]) 
            cluster_by_protein[two].append('@'.join([d['#protein'], d['condition'], d['treatment_sra_name']])  + '.bed') 

            shutil.copy(this_bed, out_bed_name) 
    print ('experimentD = ', experimentD)   
    print ('cluster_by_protein = ', cluster_by_protein) 
    print ('Done')
    
   
