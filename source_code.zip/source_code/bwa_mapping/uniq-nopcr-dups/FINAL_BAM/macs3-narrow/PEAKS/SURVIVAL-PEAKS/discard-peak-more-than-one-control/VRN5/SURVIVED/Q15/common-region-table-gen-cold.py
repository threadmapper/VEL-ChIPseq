"""
[cheemaj@NBI-HPC interactive Q15]$ singularity exec ~/BUILD/VERN/idr_bwa.sif python3 common-region-table-gen-cold.py
trt_files =  ['s_VRN5@Before_cold@VRN5-YFP-NV-rep3.bed', 's_VRN5@Before_cold@VRN5-YFP-NV-rep1.bed', 's_VRN5@Before_cold@VRN5-YFP-NV-rep2.bed']
DONE
[cheemaj@NBI-HPC interactive Q15]$ singularity exec ~/BUILD/VERN/idr_bwa.sif python3 consensus-regions-cold.py
s_VRN5@Before_cold@VRN5-YFP-NV-rep3.bed
['bedtools', 'intersect', '-a', 's_VRN5@Before_cold@VRN5-YFP-NV-rep3.bed', '-b', 'cold-multi.bed']
s_VRN5@Before_cold@VRN5-YFP-NV-rep1.bed
['bedtools', 'intersect', '-a', 's_VRN5@Before_cold@VRN5-YFP-NV-rep1.bed', '-b', 'cold-multi.bed']
s_VRN5@Before_cold@VRN5-YFP-NV-rep2.bed
['bedtools', 'intersect', '-a', 's_VRN5@Before_cold@VRN5-YFP-NV-rep2.bed', '-b', 'cold-multi.bed']
[cheemaj@NBI-HPC interactive Q15]$

"""

import subprocess
import os
import glob


categ = 'cold'

trt_files = glob.glob('s_VRN5@Cold*')

print (trt_files)


for g in trt_files:
  assert os.path.isfile(g) 

names = [trt[:-4] for trt in  trt_files]
with open(categ + '-multi.txt','w') as outf:    
    cmd = ['bedtools',  'multiinter', '-header', '-names'] + names + ['-i'] +  trt_files
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, text=True)
    for line in p.stdout:
        pipe_out = line.strip() #+ '\t@' + 'VEL1-control' ##g[:-4]) #
        outf.write(pipe_out + '\n') 

print ('trt_files = ', trt_files)
print ('DONE')
