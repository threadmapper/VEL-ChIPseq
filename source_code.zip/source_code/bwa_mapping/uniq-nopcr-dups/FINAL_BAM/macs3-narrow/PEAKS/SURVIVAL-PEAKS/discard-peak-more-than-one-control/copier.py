cp VIN3/SURVIVED/Q15/before-multi.bed vin3_before.bed
cp VIN3/SURVIVED/Q15/cold-multi.bed vin3_cold.bed
cp VEL1/SURVIVED/Q15/before-multi.bed vel1_before.bed
cp VEL1/SURVIVED/Q15/cold-multi.bed vel1_cold.bed
cp VRN5/SURVIVED/Q15/before-multi.bed vrn5_before.bed
cp VRN5/SURVIVED/Q15/cold-multi.bed vrn5_cold.bed


[cheemaj@NBI-HPC interactive discard-peak-more-than-one-control]$ wc -l *.bed
  35730 vel1_before.bed
  21352 vel1_cold.bed
     54 vin3_before.bed
   2133 vin3_cold.bed
   2451 vrn5_before.bed
   6401 vrn5_cold.bed
  68121 total
[cheemaj@NBI-HPC interactive discard-peak-more-than-one-control]$
