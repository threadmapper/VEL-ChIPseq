import glob

print [g[2:] for g in sorted(glob.glob('s_*.bed'))]

# ['VRN5@Before_cold@VRN5-YFP-NV-rep1.bed', 'VRN5@Before_cold@VRN5-YFP-NV-rep2.bed', 'VRN5@Before_cold@VRN5-YFP-NV-rep3.bed', 'VRN5@Cold@VRN5-YFP-6WT0-rep1.bed', 'VRN5@Cold@VRN5-YFP-6WT0-rep2.bed', 'VRN5@Cold@VRN5-YFP-6WT0-rep3.bed']
