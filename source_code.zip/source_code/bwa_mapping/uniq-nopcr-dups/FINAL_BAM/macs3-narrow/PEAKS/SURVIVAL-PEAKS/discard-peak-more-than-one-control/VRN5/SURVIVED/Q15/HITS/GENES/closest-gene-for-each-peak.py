import glob

from collections import defaultdict


if __name__ == '__main__':


  trt_files = glob.glob('*.bed')

  for trt in sorted(trt_files):
          
        print (trt)   
        input_gff = trt
        out_csv =   trt[:-4]     +   '-distance-to-nearest-1KBgenes.csv'
        outUnique_csv = trt[:-4] +   '-nearest1KB-genes-unique_genelist.csv'

        hits = defaultdict(list)
        uniq_genes = set()
        with open(input_gff) as inp:# , open("nearest-genes.gff", 'w') as outf:
           gene_names_uniq = set()
           for line in inp:
               A = line.strip().split()
               if A:

                  peak = A[3] # peak name

                  p_beg, p_end = int(A[1]), int(A[2])
                  g_beg, g_end = int(A[8]), int(A[9])

                  # summit check 
                  assert p_end > p_beg      
                  assert p_end - p_beg == 1

                  # gene orientation check
                  assert g_end > g_beg

                  # gene id 
                  namer = A[13]  #19 ID=AT1G01010;Note=protein_coding_gene;Name=AT1G01010
                  assert 'Name=' in namer
                  gene_name =  namer.split(';')[-1].split('=')[1]
                  gene_id =  namer.split(';')[0].split('=')[1]

                  summit = p_end  # IGV gff3 coord 
                  dist_a = g_beg - summit
                  dist_b = g_end - summit
                  dist = min( abs(dist_a), abs(dist_b))

                  if g_beg <= summit <= g_end: ## within the geneas we already checked the orientation 
                     assert  (dist_a*dist_b  <=  0), 'bad: peak ' + str(p_beg) + ' ' + str(A)  #negative
                     dist = 0

                  #print peak, dist, gene_id
                  hits[peak].append([dist, gene_id])
                  uniq_genes.add(gene_id)          

        #-----------
        peaks = []
        uniq_closest_genes_across_peaks = set()
        
        with open(out_csv, 'w') as outf: 
         for p, vect in hits.items():
            dist, g = sorted(vect, key = lambda x: x[0])[0] # closest gene
 
            assert dist <= 1000   
            peaks.append([dist, p, g])     
            uniq_closest_genes_across_peaks.add(g)
            outf.write(','.join(map(str,[dist, p, g]))+ '\n')  

        print ( 'qualified_peaks: ', len(peaks))
        print ( 'uniq_genes_found_within1KB: ', len(uniq_genes))
        print ( 'uniq_genes_closest_1KB_peaks = ', len(uniq_closest_genes_across_peaks))

        outUnique_csv = 'test.csv' 
        with open(outUnique_csv, 'w') as outf:
             for g in uniq_closest_genes_across_peaks:
                 outf.write(g + '\n')  

"""
0 Chr1
1 3001
2 3276
3 12_8_VEL1_NV_peak_1
4 259
5 .
6 3.13636
7 27.7337
8 25.9826
9 154
10 @s_VEL1@Before_cold@12_8_VEL1_NV
11 Chr1
12 TAIR10
13 gene
14 3631
15 5899
16 .
17 +
18 .
19 ID=AT1G01010;Note=protein_coding_gene;Name=AT1G01010
20 @h_s_VEL1@Before_cold@12_8_VEL1_NV


AssertionError: bad: peak 1165164 

['Chr1', '1165164', '1165165', '7_9_VEL1_6W0_peak_412', '18.7489', 'Chr1', 'TAIR10', 'gene', '1165165', '1166768', '.', '+', '.', 'ID=AT1G04350;Note=protein_coding_gene;Name=AT1G04350', '@h_s_VEL1@Cold@7_9_VEL1_6W0']



##==>
VEL1@Before_cold@12_8_VEL1_NV.bed
('qualified_peaks: ', 19186)
('uniq_genes: ', 18967)
('uniq_genes_across_peaks = ', 14581)
VEL1@Before_cold@23_9_VEL1_NV.bed
('qualified_peaks: ', 19261)
('uniq_genes: ', 18955)
('uniq_genes_across_peaks = ', 14563)
VEL1@Before_cold@31_8_VEL1_NV.bed
('qualified_peaks: ', 19361)
('uniq_genes: ', 18941)
('uniq_genes_across_peaks = ', 14607)



"""
