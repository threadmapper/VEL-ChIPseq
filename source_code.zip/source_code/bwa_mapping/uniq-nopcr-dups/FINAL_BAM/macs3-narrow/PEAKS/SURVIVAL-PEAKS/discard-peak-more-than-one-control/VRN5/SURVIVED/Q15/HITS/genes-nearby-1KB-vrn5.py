"""
# 5kb annoted as genes
/nbi/software/testing/bedtools/2.27.1/x86_64/bin/bedtools window -a T1.bed -b TAIR10_GFF3_unique_genes.gff  -w 5000
# 5kb protein coding
/nbi/software/testing/bedtools/2.27.1/x86_64/bin/bedtools window -a T1.bed -b TAIR10_GFF3_protein_coding_genes.gff  -w 5000

# 5kb annoted as genes
/nbi/software/testing/bedtools/2.27.1/x86_64/bin/bedtools window -a h_s_VEL1@Before_cold@12_8_VEL1_NV.bed -b TAIR10_GFF3_unique_genes.gff  -w 5000

"""
import subprocess
import os
import time 
import glob


def gen_submit_file(peak_file = "test.narrowPeak", sumit_file = "submit-test.bed"):

    head = ['chrom', 'beg', 'end', 'peak', 'score', 'dot', 'p', 'fold', 'q', 'offset']
    sumit_head = ['chrom', 'beg', 'end', 'peak', 'q']
    with open(peak_file) as inp, open(sumit_file, 'w') as outf:
      for line in inp:
        A = line.strip().split()
        d = dict( zip(head, A))
        d['beg'] = int(d['beg']) + int(d['offset']) 
        d['end'] = int(d['beg']) + int(d['offset']) + 1 
        pipe =  [ str(d[h]) for h in sumit_head]
        outf.write('\t'.join(pipe) + '\n')
    return sumit_file

##----before--------
#categ = 'before'

trt_files = glob.glob('h_s_*.bed')


for g in trt_files:
  print(g)
  assert os.path.isfile(g) 
  sumit_file = gen_submit_file(peak_file = g, sumit_file = "submit-" + g[4:]) 
  time.sleep(10)

  with open('GENES/' + g[4:] ,'w') as outf:    
    cmd = ['bedtools',  'window', '-a', sumit_file , '-b',  'TAIR10_GFF3_unique_genes.gff' , '-w', '1000']
    print( cmd)
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, text=True)
    for line in p.stdout:
        pipe_out = line.strip() + '\t@' + g[:-4] #
        outf.write(pipe_out + '\n') 

print ('DONE')