import sys
import pandas as pd
import altair as at

filename  = 'own-a-to-b-overlap-melt.csv'
cor_data = pd.read_csv(filename,  comment='#',)               # Skip all comments

cor_data['overlap_label'] = cor_data['overlap'].map('{:.1f}'.format)  # Round to 2 decimal
print cor_data.describe()


base = at.Chart(cor_data).encode(
    x='x:O',
    y='y:O'    
)

# Text layer with correlation labels
# Colors are for easier readability
text = base.mark_text().encode(
    text='overlap_label',
    color=at.condition(
        at.datum.overlap > 50.0, 
        at.value('white'),
        at.value('black')
    )
)

# The correlation heatmap itself
cor_plot = base.mark_rect().encode(
    color='overlap:Q'
).properties(width=300, height=300)

chart = cor_plot + text # The '+' means overlaying the text and rect layer   

#chart.properties(width=350, height=350)

chart.save('own-percentage_peak_overlap-melt.html')
   
