import glob

print [g[2:] for g in sorted(glob.glob('s_*.bed'))]