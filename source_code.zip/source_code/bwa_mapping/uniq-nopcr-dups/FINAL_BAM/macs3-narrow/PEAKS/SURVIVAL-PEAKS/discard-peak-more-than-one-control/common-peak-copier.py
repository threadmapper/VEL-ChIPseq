import glob
##
prefix = '/jic/scratch/groups/Matthew-Hartley/cheemaj/scratch/scratch-work/jitender/mathias/rebuttal/step-wise/bwa_mapping/uniq-nopcr-dups/FINAL_BAM/macs3-narrow/PEAKS/SURVIVAL-PEAKS/discard-peak-more-than-one-control'


for glb in glob.glob('*/*/*/*-multi.bed'):
    A =  glb.split('/')
    prot = A[0].lower()
    cond = A[-1].lower().split('-')[0]
    new_name =  prot + '_' + cond + '.bed'
    
    print 'cp ' + glb  + ' ' +     new_name 

 
     
