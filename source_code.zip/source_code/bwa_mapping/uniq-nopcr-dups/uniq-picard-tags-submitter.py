#! /usr/bin/env python
# -*- coding: utf-8 -*-
# pylint: disable=C0103, W1514, C0301, C0413

"""


"""

import os
import jitu


template = """#!/bin/bash -e
#SBATCH  --job-name=jobBASE
#SBATCH  -o     BASE.out
#SBATCH  -e     BASE.err
#SBATCH  --mem  40G
#SBATCH  -c     8
#SBATCH  -t     20:29:00 
#SBATCH  -p     jic-a100


mkdir -p FINAL_BAM 


singularity exec ~/BUILD/VERN/idr_bwa.sif sambamba view -t 8 -h -f bam -F "mapping_quality >= 1 and not (unmapped or secondary_alignment) and not ([XA] != null or [SA] != null)" ../BAM/BASE.bam -o BASE_uniq.bam
singularity exec ~/BUILD/VERN/idr_bwa.sif samtools index BASE_uniq.bam 
singularity exec ~/BUILD/VERN/idr_bwa.sif samtools flagstat BASE_uniq.bam  > BASE_uniq.stat


# remove reads without MAPQ>=30
singularity exec ~/BUILD/VERN/idr_bwa.sif samtools view -@ 8  -F 772  -b BASE_uniq.bam  Chr1 Chr2 Chr3 Chr4 Chr5 -o FILTER/BASE.filter_unsorted.bam
singularity exec ~/BUILD/VERN/idr_bwa.sif samtools sort -@ 8  -o FILTER/BASE.filter.bam  FILTER/BASE.filter_unsorted.bam

# Index filtered reads
singularity exec ~/BUILD/VERN/idr_bwa.sif samtools  index    FILTER/BASE.filter.bam
singularity exec ~/BUILD/VERN/idr_bwa.sif samtools  flagstat FILTER/BASE.filter.bam  > FILTER/BASE.filter.bam.stat



sleep 5s

# mark duplicates with picard
singularity exec ~/BUILD/VERN/idr_bwa.sif picard MarkDuplicates I=FILTER/BASE.filter.bam O=FILTER/BASE.dupmark_unsorted.bam  M=FILTER/BASE.dup.qc  VALIDATION_STRINGENCY=LENIENT  REMOVE_DUPLICATES=false ASSUME_SORTED=true

sleep 5s

# sort reads after marking the duplicates
singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools sort -@ 8 -o FILTER/BASE.dupmark.bam  FILTER/BASE.dupmark_unsorted.bam

# index the sorted reads
singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools index    FILTER/BASE.dupmark.bam
singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools flagstat FILTER/BASE.dupmark.bam > FILTER/BASE.dupmark.bam.stat


# remove duplicates
singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools view -@ 8  -F 1796  -b FILTER/BASE.dupmark.bam -o  FILTER/BASE.dupmark.nodup_unsorted.bam

singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools sort -@ 8  -o FINAL_BAM/BASE.bam  FILTER/BASE.dupmark.nodup_unsorted.bam

# index unique reads
singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools  index     FINAL_BAM/BASE.bam
singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools  flagstat  FINAL_BAM/BASE.bam >  FINAL_BAM/BASE.bam.stat




echo DONE

"""


if __name__ == '__main__':

    samples2fastq_concatted = {'VEL1-FLAG-NV-rep1': 'VEL1-FLAG-NV-rep1.fq.gz', 'VEL1-FLAG-NV-rep3': 'VEL1-FLAG-NV-rep3.fq.gz', 'VEL1-FLAG-NV-rep2': 'VEL1-FLAG-NV-rep2.fq.gz', 'ColFRI-6WT0-Input-for-ColFRI-FLAG-Rep1': 'ColFRI-6WT0-Input-for-ColFRI-FLAG-Rep1.fq.gz', 'ColFRI-NV-IP-For-GFP-ColFR-Rep2': 'ColFRI-NV-IP-For-GFP-ColFR-Rep2.fq.gz', 'VRN5-YFP-NV-rep3': 'VRN5-YFP-NV-rep3.fq.gz', 'VEL1-FLAG-6WT0-rep1': 'VEL1-FLAG-6WT0-rep1.fq.gz', 'VEL1-FLAG-6WT0-rep2': 'VEL1-FLAG-6WT0-rep2.fq.gz', 'VEL1-FLAG-6WT0-rep3': 'VEL1-FLAG-6WT0-rep3.fq.gz', 'VEL1-FLAG-NV-input-rep2': 'VEL1-FLAG-NV-input-rep2.fq.gz', 'VEL1-FLAG-NV-input-rep3': 'VEL1-FLAG-NV-input-rep3.fq.gz', 'VEL1-FLAG-NV-input-rep1': 'VEL1-FLAG-NV-input-rep1.fq.gz', 'VIN3-eGFP-6WT0-rep1': 'VIN3-eGFP-6WT0-rep1.fq.gz', 'VIN3-eGFP-6WT0-rep2': 'VIN3-eGFP-6WT0-rep2.fq.gz', 'VIN3-eGFP-6WT0-rep3': 'VIN3-eGFP-6WT0-rep3.fq.gz', 'VIN3-eGFP-NV-rep1': 'VIN3-eGFP-NV-rep1.fq.gz', 'VRN5-YFP-6WT0-rep2': 'VRN5-YFP-6WT0-rep2.fq.gz', 'VRN5-YFP-6WT0-rep1': 'VRN5-YFP-6WT0-rep1.fq.gz', 'VIN3-eGFP-NV-rep2': 'VIN3-eGFP-NV-rep2.fq.gz', 'ColFRI-NV-IP-for-ColFRI-FLAG-Rep1': 'ColFRI-NV-IP-for-ColFRI-FLAG-Rep1.fq.gz', 'ColFRI-NV-IP-for-ColFRI-FLAG-Rep2': 'ColFRI-NV-IP-for-ColFRI-FLAG-Rep2.fq.gz', 'VIN3-eGFP-NV-input-rep2': 'VIN3-eGFP-NV-input-rep2.fq.gz', 'ColFRI-6WT0-For-GFP-ColFR-Rep1': 'ColFRI-6WT0-For-GFP-ColFR-Rep1.fq.gz', 'ColFRI-6WT0-For-GFP-ColFR-Rep2': 'ColFRI-6WT0-For-GFP-ColFR-Rep2.fq.gz', 'ColFRI-6WT0-Input-For-GFP-ColFR-Rep1': 'ColFRI-6WT0-Input-For-GFP-ColFR-Rep1.fq.gz', 'VRN5-YFP-6WT0-input-rep1': 'VRN5-YFP-6WT0-input-rep1.fq.gz', 'VRN5-YFP-6WT0-input-rep2': 'VRN5-YFP-6WT0-input-rep2.fq.gz', 'VRN5-YFP-6WT0-input-rep3': 'VRN5-YFP-6WT0-input-rep3.fq.gz', 'ColFRI-NV-input-for-ColFRI-FLAG-Rep2': 'ColFRI-NV-input-for-ColFRI-FLAG-Rep2.fq.gz', 'ColFRI-NV-input-for-ColFRI-FLAG-Rep1': 'ColFRI-NV-input-for-ColFRI-FLAG-Rep1.fq.gz', 'VRN5-YFP-NV-rep2': 'VRN5-YFP-NV-rep2.fq.gz', 'VEL1-FLAG-6WT0-input-rep3': 'VEL1-FLAG-6WT0-input-rep3.fq.gz', 'VEL1-FLAG-6WT0-input-rep2': 'VEL1-FLAG-6WT0-input-rep2.fq.gz', 'VEL1-FLAG-6WT0-input-rep1': 'VEL1-FLAG-6WT0-input-rep1.fq.gz', 'VIN3-eGFP-NV-input-rep1': 'VIN3-eGFP-NV-input-rep1.fq.gz', 'VIN3-eGFP-6WT0-input-rep3': 'VIN3-eGFP-6WT0-input-rep3.fq.gz', 'VIN3-eGFP-6WT0-input-rep2': 'VIN3-eGFP-6WT0-input-rep2.fq.gz', 'VIN3-eGFP-6WT0-input-rep1': 'VIN3-eGFP-6WT0-input-rep1.fq.gz', 'VRN5-YFP-NV-rep1': 'VRN5-YFP-NV-rep1.fq.gz', 'ColFRI-NV-input-For-GFP-ColFR-Rep2': 'ColFRI-NV-input-For-GFP-ColFR-Rep2.fq.gz', 'ColFRI-NV-input-For-GFP-ColFR-Rep1': 'ColFRI-NV-input-For-GFP-ColFR-Rep1.fq.gz', 'VRN5-YFP-6WT0-rep3': 'VRN5-YFP-6WT0-rep3.fq.gz', 'ColFRI-NV-IP-For-GFP-ColFR-Rep1': 'ColFRI-NV-IP-For-GFP-ColFR-Rep1.fq.gz', 'VRN5-YFP-NV-input-rep1': 'VRN5-YFP-NV-input-rep1.fq.gz', 'ColFRI-6WT0-Input-For-GFP-ColFR-Rep2': 'ColFRI-6WT0-Input-For-GFP-ColFR-Rep2.fq.gz', 'VRN5-YFP-NV-input-rep3': 'VRN5-YFP-NV-input-rep3.fq.gz', 'VRN5-YFP-NV-input-rep2': 'VRN5-YFP-NV-input-rep2.fq.gz', 'ColFRI-6WT0-for-ColFRI-FLAG-Rep1': 'ColFRI-6WT0-for-ColFRI-FLAG-Rep1.fq.gz' , 'CLF-GFP-Rep2': 'CLF-GFP-Rep2.fq.gz', 'CLF-GFP-Rep1': 'CLF-GFP-Rep1.fq.gz', '35S_GFP_input_control': '35S_GFP_input_control.fq.gz', 'SWN-GFP-Rep2': 'SWN-GFP-Rep2.fq.gz', 'SWN-GFP-Rep1': 'SWN-GFP-Rep1.fq.gz'}
   

    # construct a job array
    with open('all-batch.sh', 'w') as bout:

        for t, sample in enumerate(samples2fastq_concatted.keys(), 1):

            
            st = jitu.strMUT(template, {
                'SER': str(t),
                'BASE': sample,
                  })

            with open('job' + str(t) + '.sh', 'w') as outf:
                outf.write(st)
            bout.write('sbatch ' + 'job' + str(t) + '.sh' + '\n')

print('DONE')
