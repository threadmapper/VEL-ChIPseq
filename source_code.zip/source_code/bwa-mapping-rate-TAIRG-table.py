#! /usr/bin/env python
# -*- coding: utf-8 -*-
# pylint: disable=C0103, W1514, C0301, C0413

"""

Collate a mapping rate table from samtools flagstat text file:
For example:
  samtools flagstat sorted-15_9ColFRINVinp.bam  >  tob1.out


parsing tob1.out file:
37976891 + 0 in total (QC-passed reads + QC-failed reads)
0 + 0 secondary
0 + 0 supplementary
0 + 0 duplicates
30843597 + 0 mapped (81.22% : N/A)
0 + 0 paired in sequencing
0 + 0 read1
0 + 0 read2
0 + 0 properly paired (N/A : N/A)
0 + 0 with itself and mate mapped
0 + 0 singletons (N/A : N/A)
0 + 0 with mate mapped to a different chr
0 + 0 with mate mapped to a different chr (mapQ>=5)
30843597
DONE
# tob12.out
samtools flagstat sorted-31_7_COIFRI_NV_IP.bam  > tob12.out

"""

import glob


def find_mapping_rate(input_file):
    """  parse file for the mapping information lines """
    with open(input_file) as input_handle:
        for line in input_handle:
            tokens = line.strip().split()
            if '+ 0 in total (QC-passed reads ' in line:
                total_reads = int(tokens[0])
            if 'mapped (' in line:
                mapped_reads = int(tokens[0])
    return mapped_reads, total_reads


if __name__ == '__main__':

    # load all the samples info to reads name from the tsv
    samples = [ g[:-5] for g in glob.glob('*.stat')]

    # enumerate through each file
    with open('bwa-TAIRG-mapping-rate-table.csv', 'w') as outf:
        pipe = ['serial', 'sample', 'lib_id',  'mapped_reads', 'total_reads', 'mapping_rate']
        outf.write(','.join(map(str, pipe)) + '\n')
        for t, sample in enumerate(samples, 1):
            filer =  sample + '.stat'
            lib_id =  sample #samples2lib_id[sample]

            mapped_reads_, total_reads_ = find_mapping_rate(filer)
            mapping_rate = 100 * mapped_reads_ / float(total_reads_)
            pipe = [t, sample, lib_id, mapped_reads_, total_reads_, f'{mapping_rate:.2f}']
            outf.write(','.join([str(_) for _ in pipe]) + '\n')
    print('Done')

"""
output:
    serial,sample,output_file,mapped_reads,total_reads,mapping_rate
    1,15_9ColFRINVinp,tob1.out,30843597,37976891,81.22
    2,15_9_ColFRINVIP,tob2.out,28261352,37917070,74.53
    3,16_9VEL16W0inpu,tob3.out,29167482,37972699,76.81
    4,16_9_VEL16W0_IP,tob4.out,21180273,37916880,55.86
    5,21_9FRI6W0input,tob5.out,32049820,37928154,84.50
    6,21_9_FRI_6W0_IP,tob6.out,27890125,37811092,73.76
    7,23_9VEL1NVinput,tob7.out,33524543,37913900,88.42
    8,23_9_VEL1_NV_IP,tob8.out,34938726,37954085,92.06
    9,31_8VEL1NVinput,tob9.out,33693185,37793475,89.15
    10,31_8_VEL1_NV_IP,tob10.out,30495863,34798185,87.64
    11,7_4VRN56W0IP,tob11.out,28516532,37918134,75.21
    12,7_4VRN56W0input,tob12.out,28801455,37822524,76.15
    13,7_9VEL16W0input,tob13.out,29499523,37954601,77.72
    14,7_9_VEL1_6W0_IP,tob14.out,32651891,37846890,86.27
    15,9_9FRINVinput,tob15.out,30746186,38005385,80.90
    16,9_9_FRI_NV_IP,tob16.out,26362093,37875078,69.60

"""
