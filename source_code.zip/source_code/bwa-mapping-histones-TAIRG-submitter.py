#! /usr/bin/env python
# -*- coding: utf-8 -*-
# pylint: disable=C0103, W1514, C0301, C0413

"""

submit BWA mapping jobs to slurm for each SE reads

"""

import os
import jitu


template = """#!/bin/bash -e
#SBATCH  --job-name=jobBASE
#SBATCH  -o     BASE.out
#SBATCH  -e     BASE.err
#SBATCH  --mem  40G
#SBATCH  -c     8
#SBATCH  -t     20:29:00 
#SBATCH  -p     jic-medium

#aln -t using 8 threads
# -l 32        seed length
# -k 2         mismatches allowed in seed
# -q 5


mkdir -p BAM





#singularity exec ~/BUILD/VERN/idr_bwa.sif bwa aln -q 5 -l 32 -k 2 -t 8 ../ref/TAIR10Genome.fasta  FASTQ_FWD    > BASE_1.sai
#singularity exec ~/BUILD/VERN/idr_bwa.sif bwa aln -q 5 -l 32 -k 2 -t 8 ../ref/TAIR10Genome.fasta  FASTQ_REV    > BASE_2.sai
 
sleep 2s

#for bwa samse: we are building sam
singularity exec ~/BUILD/VERN/idr_bwa.sif bwa sampe ../ref/TAIR10Genome.fasta   BASE_1.sai  BASE_2.sai   FASTQ_FWD  FASTQ_REV  > BASE.sam


singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools view -bt ../ref/TAIR10Genome.fasta -o BASE_unsorted.bam  BASE.sam

singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools sort -@ 8  -o  BAM/BASE.bam  BASE_unsorted.bam
 
singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools index    BAM/BASE.bam 

singularity exec ~/BUILD/VERN/idr_bwa.sif  samtools flagstat BAM/BASE.bam  >  BASE.stat

# rm BASE_unsorted.bam
# rm BASE.sam

echo DONE

"""


if __name__ == '__main__':

    # load all the samples info to reads name from the tsv

    samples = ['NV_input_control', 'H3K27me3_NV_1', 'VAL1-GFP-val1-Rep2', 'VAL1-GFP-val1-Rep1', 'H3K27me3_NV_2', '40V_H3K27_me3_rep2', 'VAL1-GFP-val1-input-control', '40V_input_control']
  

    # construct a job array
    with open('all-batch.sh', 'w') as bout:

        for t, sample in enumerate(sorted(samples), 1):

            fastq_file_fwd =  sample + '_1.fq.gz'
            fastq_file_rev =  sample + '_2.fq.gz'

            assert os.path.exists(fastq_file_fwd)
            assert os.path.exists(fastq_file_fwd)

            st = jitu.strMUT(template, {
                'SER': str(t),
                'BASE': sample,
                'FASTQ_FWD': fastq_file_fwd, 'FASTQ_REV': fastq_file_rev,})

            with open('job' + str(t) + '.sh', 'w') as outf:
                outf.write(st)
            bout.write('sbatch ' + 'job' + str(t) + '.sh' + '\n')

print('DONE')
